# Roadmap Phase — File Set

This archive contains ONLY the files changed for the Roadmap phase, with the
same relative paths as in `fluxrico/Fluxrico-Foundation`. Copy them into your
existing checkout, overwriting the 3 modified files in place.

## Created (new files — copy in as-is)
- artifacts/fluxrico/src/pages/roadmap.tsx
- artifacts/fluxrico/src/components/roadmap-stage-cards.tsx

## Modified (overwrite the existing files with these versions)
- artifacts/fluxrico/src/App.tsx
- artifacts/fluxrico/src/pages/dashboard.tsx
- artifacts/fluxrico/src/pages/navigator-result.tsx

## How to apply

From the root of your `Fluxrico-Foundation` checkout:

```bash
# unzip this archive somewhere, then:
cp -r roadmap-patch/artifacts ./
```

Or manually copy each file into the matching path, replacing the 3 existing
ones and adding the 2 new ones.

## After applying

```bash
pnpm run typecheck
pnpm run build
```

No other files in the project were touched. No `node_modules`, lockfiles, or
build output are included in this archive.
